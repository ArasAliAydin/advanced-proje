"""Oda değerlendirme ve arıza bildirimi."""
from sqlmodel import select

from app.core import clock
from app.models import EmailLog
from tests.conftest import API, at, auth, book


def attended(client, user, room, day=0, hour=10):
    """Kullanıcı adına rezervasyon yapıp check-in eder; rezervasyon kimliğini döndürür."""
    r = book(client, user, room, at(day, hour), at(day, hour + 1)).json()
    clock.freeze(at(day, hour))
    assert client.post(f"{API}/checkin", json={"code": r["checkin_code"]}, headers=auth(user)).status_code == 200
    return r["id"]


def rate(client, user, reservation_id, score=5, comment=""):
    payload = {"reservation_id": reservation_id, "score": score, "comment": comment}
    return client.post(f"{API}/ratings", json=payload, headers=auth(user))


def report(client, user, room, category="equipment", description="Projeksiyon açılmıyor", **extra):
    payload = {"room_id": room.id, "category": category, "description": description, **extra}
    return client.post(f"{API}/issues", json=payload, headers=auth(user))


# ---------------------------------------------------------------- Puanlama
def test_rate_attended_reservation(client, make_user, room):
    ali = make_user("ali")
    rid = attended(client, ali, room)
    r = rate(client, ali, rid, 4, "  Sessiz ve temiz  ")
    assert r.status_code == 201
    assert r.json()["score"] == 4 and r.json()["comment"] == "Sessiz ve temiz" and r.json()["room_id"] == room.id
    assert [x["reservation_id"] for x in client.get(f"{API}/ratings/me", headers=auth(ali)).json()] == [rid]


def test_rate_only_once(client, make_user, room):
    ali = make_user("ali")
    rid = attended(client, ali, room)
    assert rate(client, ali, rid).status_code == 201
    r = rate(client, ali, rid, 1)
    assert r.status_code == 409 and r.json()["code"] == "already_rated"


def test_cannot_rate_without_attending(client, make_user, admin, room):
    ali = make_user("ali")
    upcoming = book(client, ali, room, at(1, 10), at(1, 11)).json()["id"]
    r = rate(client, ali, upcoming)
    assert r.status_code == 409 and r.json()["code"] == "not_attended"

    # Gelmeyen (no-show) rezervasyon da puanlanamaz
    missed = book(client, ali, room, at(0, 12), at(0, 13)).json()["id"]
    clock.freeze(at(0, 12, 20))
    client.post(f"{API}/admin/jobs/run", headers=auth(admin))
    assert rate(client, ali, missed).json()["code"] == "not_attended"


def test_cannot_rate_others_reservation(client, make_user, room):
    ali, veli = make_user("ali"), make_user("veli")
    rid = attended(client, ali, room)
    r = rate(client, veli, rid)
    assert r.status_code == 403 and r.json()["code"] == "forbidden"
    assert rate(client, veli, 9999).status_code == 404


def test_score_must_be_between_1_and_5(client, make_user, room):
    ali = make_user("ali")
    rid = attended(client, ali, room)
    assert rate(client, ali, rid, 0).status_code == 422
    assert rate(client, ali, rid, 6).status_code == 422
    assert rate(client, ali, rid, 3, "x" * 501).status_code == 422


def test_completed_reservation_can_be_rated(client, make_user, admin, room):
    ali = make_user("ali")
    rid = attended(client, ali, room)
    clock.freeze(at(0, 11))
    client.post(f"{API}/admin/jobs/run", headers=auth(admin))
    assert client.get(f"{API}/reservations/{rid}", headers=auth(ali)).json()["status"] == "completed"
    assert rate(client, ali, rid, 5).status_code == 201


def test_summary_and_reviews(client, make_user, room, hall):
    ali, veli = make_user("ali"), make_user("veli")
    rate(client, ali, attended(client, ali, room, hour=10), 5, "Harika")
    rate(client, veli, attended(client, veli, room, hour=12), 2)
    rate(client, ali, attended(client, ali, room, hour=14), 4, "İyi ama soğuk")
    report(client, veli, room)

    summaries = {s["room_id"]: s for s in client.get(f"{API}/ratings/summary", headers=auth(ali)).json()}
    assert summaries[room.id]["average"] == 3.67 and summaries[room.id]["count"] == 3
    assert summaries[room.id]["distribution"] == {"5": 1, "4": 1, "3": 0, "2": 1, "1": 0}
    assert summaries[room.id]["open_issues"] == 1
    assert summaries[hall.id] == {"room_id": hall.id, "average": None, "count": 0,
                                  "distribution": {"5": 0, "4": 0, "3": 0, "2": 0, "1": 0}, "open_issues": 0}

    reviews = client.get(f"{API}/ratings/rooms/{room.id}", headers=auth(veli)).json()
    # Yalnızca yorumlu puanlar listelenir, en yeni önce; kimlik bilgisi yok
    assert [(r["score"], r["comment"]) for r in reviews["reviews"]] == [(4, "İyi ama soğuk"), (5, "Harika")]
    assert "user_id" not in reviews["reviews"][0]
    assert client.get(f"{API}/ratings/rooms/999", headers=auth(ali)).status_code == 404


# ---------------------------------------------------------------- Arıza bildirimi
def test_report_issue(client, make_user, room):
    ali = make_user("ali")
    r = report(client, ali, room, "power", "Masadaki prizler çalışmıyor")
    assert r.status_code == 201
    body = r.json()
    assert body["status"] == "open" and body["category"] == "power" and body["room_name"] == "Oda A"
    assert body["user_name"] is None  # öğrenci kendi kaydında bile kimlik alanı görmez
    assert [i["id"] for i in client.get(f"{API}/issues/me", headers=auth(ali)).json()] == [body["id"]]


def test_issue_validation(client, make_user, room):
    ali = make_user("ali")
    assert report(client, ali, room, description="kısa").status_code == 422
    assert report(client, ali, room, category="uzayli").status_code == 422
    payload = {"room_id": 999, "category": "other", "description": "Oda bulunamadı mı?"}
    r = client.post(f"{API}/issues", json=payload, headers=auth(ali))
    assert r.status_code == 404 and r.json()["code"] == "room_not_found"


def test_duplicate_open_issue_rejected(client, make_user, admin, room):
    ali, veli = make_user("ali"), make_user("veli")
    first = report(client, ali, room).json()
    r = report(client, ali, room, description="Yine projeksiyon")
    assert r.status_code == 409 and r.json()["code"] == "duplicate_issue" and r.json()["issue_id"] == first["id"]
    # Başka tür ya da başka öğrenci bildirebilir
    assert report(client, ali, room, "cleanliness", "Masalar kirli").status_code == 201
    assert report(client, veli, room).status_code == 201
    # Çözüldükten sonra aynı tür yeniden bildirilebilir
    client.patch(f"{API}/issues/{first['id']}", json={"status": "resolved"}, headers=auth(admin))
    assert report(client, ali, room).status_code == 201


def test_issue_with_reservation_must_be_own(client, make_user, room, hall):
    ali, veli = make_user("ali"), make_user("veli")
    rid = book(client, ali, room, at(1, 10), at(1, 11)).json()["id"]
    assert report(client, ali, room, reservation_id=rid).status_code == 201
    assert report(client, veli, room, reservation_id=rid).status_code == 403
    # Rezervasyon başka odaya aitse de reddedilir
    assert report(client, ali, hall, reservation_id=rid).status_code == 403


def test_admin_resolves_and_reopens_issue(client, session, make_user, admin, room):
    ali = make_user("ali")
    issue = report(client, ali, room).json()
    listed = client.get(f"{API}/issues", headers=auth(admin)).json()
    assert [i["id"] for i in listed] == [issue["id"]] and listed[0]["user_name"] == "Ali"

    clock.freeze(at(0, 11))
    r = client.patch(f"{API}/issues/{issue['id']}", json={"status": "resolved", "resolution_note": "Lamba değişti"},
                     headers=auth(admin))
    assert r.status_code == 200
    body = r.json()
    assert body["status"] == "resolved" and body["resolved_by"] == admin.id
    assert body["resolution_note"] == "Lamba değişti" and body["resolved_at"] == at(0, 11).isoformat()
    mail = session.exec(select(EmailLog).where(EmailLog.kind == "issue_resolved")).one()
    assert mail.to_email == ali.email and "Lamba değişti" in mail.body

    again = client.patch(f"{API}/issues/{issue['id']}", json={"status": "resolved"}, headers=auth(admin))
    assert again.status_code == 409 and again.json()["code"] == "issue_unchanged"

    reopened = client.patch(f"{API}/issues/{issue['id']}", json={"status": "open"}, headers=auth(admin)).json()
    assert reopened["status"] == "open" and reopened["resolved_at"] is None and reopened["resolution_note"] is None


def test_admin_issue_filters_and_permissions(client, make_user, admin, room, hall):
    ali = make_user("ali")
    a = report(client, ali, room).json()
    b = report(client, ali, hall, "noise", "Havalandırma çok gürültülü").json()
    client.patch(f"{API}/issues/{a['id']}", json={"status": "resolved"}, headers=auth(admin))

    assert [i["id"] for i in client.get(f"{API}/issues", headers=auth(admin)).json()] == [b["id"], a["id"]]  # açık önce
    assert [i["id"] for i in client.get(f"{API}/issues", params={"status": "open"}, headers=auth(admin)).json()] == [b["id"]]
    assert [i["id"] for i in client.get(f"{API}/issues", params={"room_id": room.id}, headers=auth(admin)).json()] == [a["id"]]

    assert client.get(f"{API}/issues", headers=auth(ali)).status_code == 403
    assert client.patch(f"{API}/issues/{b['id']}", json={"status": "resolved"}, headers=auth(ali)).status_code == 403
    assert client.patch(f"{API}/issues/999", json={"status": "resolved"}, headers=auth(admin)).status_code == 404


# ---------------------------------------------------------------- Web arayüzü
def test_feedback_web_assets(client):
    page = client.get("/").text
    assert "/static/feedback.js" in page
    assert page.index("/static/feedback.js") < page.index("/static/admin.js")  # admin.js adminIssues'u kullanır
    js = client.get("/static/feedback.js")
    assert js.status_code == 200 and "javascript" in js.headers["content-type"]
    assert "async function adminIssues" in js.text and 'api("/ratings/summary")' in js.text
    assert '"issues"' in client.get("/static/admin.js").text
