"""Oda değerlendirme (puan + yorum) ve arıza bildirimi endpoint'leri."""
from fastapi import APIRouter, HTTPException, Query, status

from app.core import clock
from app.core.deps import AdminUser, CurrentUser, SessionDep
from app.models import IssueReport, IssueStatus, Room
from app.schemas import IssueCreate, IssueRead, IssueUpdate, RatingCreate, RatingRead, RoomRatingSummary, RoomReviews
from app.services import feedback

ratings_router = APIRouter(prefix="/ratings", tags=["Değerlendirme"])
issues_router = APIRouter(prefix="/issues", tags=["Arıza bildirimi"])


# ---------------------------------------------------------------- Puanlama
@ratings_router.post("", response_model=RatingRead, status_code=status.HTTP_201_CREATED)
def rate_room(data: RatingCreate, session: SessionDep, user: CurrentUser):
    """Katıldığınız (check-in yaptığınız) bir rezervasyonun odasına 1–5 puan ve isteğe bağlı yorum verir.

    Her rezervasyon bir kez puanlanır (409 `already_rated`); katılmadığınız rezervasyon 409 `not_attended`.
    """
    return feedback.rate(session, user, data.reservation_id, data.score, data.comment, clock.now())


@ratings_router.get("/me", response_model=list[RatingRead])
def my_ratings(session: SessionDep, user: CurrentUser):
    return feedback.my_ratings(session, user)


@ratings_router.get("/summary", response_model=list[RoomRatingSummary])
def rating_summaries(session: SessionDep, _: CurrentUser):
    """Her odanın ortalama puanı, puan sayısı, dağılımı ve açık arıza sayısı."""
    return feedback.summaries(session)


@ratings_router.get("/rooms/{room_id}", response_model=RoomReviews)
def room_reviews(room_id: int, session: SessionDep, _: CurrentUser, limit: int = Query(5, ge=1, le=50)):
    """Odanın puan özeti ve son yorumları (yorum yapanın kimliği gösterilmez)."""
    room = session.get(Room, room_id)
    if room is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Oda bulunamadı")
    return feedback.room_reviews(session, room, limit)


# ---------------------------------------------------------------- Arıza bildirimi
@issues_router.post("", response_model=IssueRead, status_code=status.HTTP_201_CREATED)
def report_issue(data: IssueCreate, session: SessionDep, user: CurrentUser):
    """Odadaki bir sorunu bildirir (ör. projeksiyon bozuk). Aynı türde açık bildirim varsa 409 `duplicate_issue`."""
    issue = feedback.report_issue(
        session, user, data.room_id, data.category, data.description, data.reservation_id, clock.now()
    )
    return feedback.to_read(session, issue, user)


@issues_router.get("/me", response_model=list[IssueRead])
def my_issues(session: SessionDep, user: CurrentUser):
    return [feedback.to_read(session, i, user) for i in feedback.list_issues(session, user=user)]


@issues_router.get("", response_model=list[IssueRead])
def list_issues(
    session: SessionDep, admin: AdminUser, status_filter: IssueStatus | None = Query(None, alias="status"),
    room_id: int | None = None,
):
    """[Admin] Tüm arıza bildirimleri; açık olanlar önce."""
    return [feedback.to_read(session, i, admin) for i in feedback.list_issues(session, status=status_filter, room_id=room_id)]


@issues_router.patch("/{issue_id}", response_model=IssueRead)
def update_issue(issue_id: int, data: IssueUpdate, session: SessionDep, admin: AdminUser):
    """[Admin] Bildirimi çözüldü olarak işaretler (bildirene e-posta gider) ya da yeniden açar."""
    issue = session.get(IssueReport, issue_id)
    if issue is None:
        raise HTTPException(status.HTTP_404_NOT_FOUND, "Bildirim bulunamadı")
    issue = feedback.update_issue(session, issue, admin, data.status, data.resolution_note, clock.now())
    return feedback.to_read(session, issue, admin)
