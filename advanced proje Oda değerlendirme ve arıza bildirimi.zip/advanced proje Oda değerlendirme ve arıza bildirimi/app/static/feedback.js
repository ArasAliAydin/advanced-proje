/* StudySpot web arayüzü — Oda değerlendirme ve arıza bildirimi.
 * - Oda kartlarında ortalama puan ve açık arıza rozeti
 * - Oda ayrıntısında puan dağılımı, son yorumlar ve "Arıza bildir" düğmesi
 * - Rezervasyonlarım: katılınan rezervasyona "Puan ver", arıza bildirimlerim listesi
 * - Yönetim → Arızalar bölümü (admin.js'teki sekmelerden biri)
 * app.js'teki h(), api(), t(), openModal(), confirmModal() yardımcılarını kullanır.
 */
"use strict";

const ISSUE_CATEGORIES = ["equipment", "power", "cleanliness", "furniture", "noise", "other"];
const RATED_STATUSES = ["checked_in", "completed"];

const stars = (score) => "★".repeat(Math.round(score)) + "☆".repeat(5 - Math.round(score));
const fmtAvg = (x) => Number(x).toLocaleString(i18n.locale, { minimumFractionDigits: 1, maximumFractionDigits: 1 });
const issueBadge = (s) => badge(t(`issue.status.${s}`), s === "open" ? "warn" : "ok");

// ---------------------------------------------------------------- Oda kartları
/* Oda kartlarına puan ve arıza rozetlerini ekler. `cards`: Map(roomId -> kart elemanı).
 * Tek istekle tüm odaların özeti alınır; hata olursa kartlar rozetsiz kalır. */
async function decorateRoomCardsWithRatings(cards) {
  let summaries;
  try { summaries = await api("/ratings/summary"); } catch { return; }
  for (const s of summaries) {
    const card = cards.get(s.room_id);
    const meta = card && card.querySelector(".meta");
    if (!meta) continue;
    meta.querySelectorAll(".rating-badge").forEach((el) => el.remove());
    if (s.count) {
      meta.prepend(h("span", { class: "badge rating-badge", title: t("rating.cardTitle", { avg: fmtAvg(s.average), n: s.count }) },
        `★ ${fmtAvg(s.average)} (${fmtNum(s.count)})`));
    }
    if (s.open_issues) meta.append(h("span", { class: "badge warn rating-badge" }, t("issue.cardBadge", { n: s.open_issues })));
  }
}

// ---------------------------------------------------------------- Oda ayrıntısı
function roomFeedbackSection(room) {
  const box = h("div", { class: "stack" }, h("p", { class: "muted small" }, t("app.loading")));
  const reportBtn = h("button", { class: "btn ghost small", type: "button", onclick: () => openIssueForm(room) }, `⚠ ${t("issue.report")}`);
  const section = h("div", { class: "feedback-section" },
    h("div", { class: "row spread" }, h("h3", { style: "margin:0" }, t("rating.title")), reportBtn),
    box,
  );
  api(`/ratings/rooms/${room.id}`)
    .then((data) => box.replaceChildren(...ratingSummaryView(data)))
    .catch((err) => box.replaceChildren(errorBox(err)));
  return section;
}

function ratingSummaryView(data) {
  const issues = data.open_issues
    ? h("div", { class: "alert info small" }, t("issue.openInRoom", { n: data.open_issues })) : null;
  if (!data.count) return [h("p", { class: "muted small" }, t("rating.none")), issues];
  const max = Math.max(...Object.values(data.distribution), 1);
  const bars = h("div", { class: "rating-bars" },
    [5, 4, 3, 2, 1].map((s) => {
      const n = data.distribution[s] || 0;
      return h("div", { class: "rating-bar-row" },
        h("span", { class: "small" }, `${s} ★`),
        h("span", { class: "rating-bar" }, h("i", { style: `width:${Math.round((n / max) * 100)}%` })),
        h("span", { class: "small muted num" }, fmtNum(n)));
    }));
  const reviews = data.reviews.length
    ? data.reviews.map((r) => h("div", { class: "list-item review" },
      h("div", null,
        h("div", { class: "row" }, h("span", { class: "stars", "aria-label": t("rating.scoreAria", { n: r.score }) }, stars(r.score)),
          h("span", { class: "muted small" }, fmtDay(dayOf(r.created_at), { day: "numeric", month: "short" }))),
        h("div", null, r.comment))))
    : [h("p", { class: "muted small" }, t("rating.noComments"))];
  return [
    h("div", { class: "rating-summary" },
      h("div", { class: "rating-big" },
        h("b", null, fmtAvg(data.average)),
        h("span", { class: "stars" }, stars(data.average)),
        h("span", { class: "muted small" }, t("rating.count", { n: fmtNum(data.count) }))),
      bars),
    issues,
    h("div", null, h("div", { class: "muted small" }, t("rating.recent")), reviews),
  ];
}

// ---------------------------------------------------------------- Puan verme
function openRatingForm(reservation, onDone) {
  let score = 0;
  const error = h("div");
  const starButtons = [1, 2, 3, 4, 5].map((s) => h("button", {
    type: "button", class: "star-btn", "aria-label": t("rating.scoreAria", { n: s }), "aria-pressed": "false",
    onclick: () => { score = s; paint(); },
  }, "☆"));
  const paint = () => starButtons.forEach((b, i) => {
    b.textContent = i < score ? "★" : "☆";
    b.setAttribute("aria-pressed", String(i < score));
  });
  const comment = h("textarea", { id: "rating-comment", maxlength: 500, rows: 3, placeholder: t("rating.commentPlaceholder") });
  const submit = h("button", { class: "btn", type: "submit" }, t("rating.submit"));
  const form = h("form", {
    class: "stack",
    onsubmit: async (ev) => {
      ev.preventDefault();
      if (!score) { error.replaceChildren(h("div", { class: "alert error" }, t("rating.pickScore"))); return; }
      submit.disabled = true;
      try {
        await api("/ratings", { method: "POST", json: { reservation_id: reservation.id, score, comment: comment.value } });
        closeModal();
        toast(t("rating.thanks"));
        onDone && onDone();
      } catch (err) {
        submit.disabled = false;
        error.replaceChildren(errorBox(err));
      }
    },
  },
  h("div", null, h("b", null, reservation.room_name || roomName(reservation.room_id)),
    h("div", { class: "muted small" }, fmtRange(reservation.start_time, reservation.end_time))),
  h("div", { class: "star-picker", role: "group", "aria-label": t("rating.score") }, starButtons),
  h("div", null, h("label", { for: "rating-comment" }, t("rating.comment")), comment),
  error,
  h("div", { class: "row" }, submit, h("button", { class: "btn ghost", type: "button", onclick: closeModal }, t("common.cancel"))),
  );
  openModal(t("rating.formTitle"), form);
}

// ---------------------------------------------------------------- Arıza bildirme
function openIssueForm(room, reservation = null, onDone = null) {
  const category = h("select", { id: "issue-category" },
    ISSUE_CATEGORIES.map((c) => h("option", { value: c }, t(`issue.cat.${c}`))));
  const description = h("textarea", { id: "issue-description", required: true, minlength: 5, maxlength: 500, rows: 4,
    placeholder: t("issue.descriptionPlaceholder") });
  const error = h("div");
  const submit = h("button", { class: "btn", type: "submit" }, t("issue.send"));
  const form = h("form", {
    class: "stack",
    onsubmit: async (ev) => {
      ev.preventDefault();
      submit.disabled = true;
      const payload = { room_id: room.id, category: category.value, description: description.value };
      if (reservation) payload.reservation_id = reservation.id;
      try {
        await api("/issues", { method: "POST", json: payload });
        closeModal();
        toast(t("issue.sent"));
        onDone ? onDone() : refreshCurrent();
      } catch (err) {
        submit.disabled = false;
        error.replaceChildren(errorBox(err, (name) => t(`issue.f.${name}`)));
      }
    },
  },
  h("div", null, h("b", null, room.name || roomName(room.id)), h("div", { class: "muted small" }, t("issue.lead"))),
  h("div", null, h("label", { for: "issue-category" }, t("issue.f.category")), category),
  h("div", null, h("label", { for: "issue-description" }, t("issue.f.description")), description),
  error,
  h("div", { class: "row" }, submit, h("button", { class: "btn ghost", type: "button", onclick: closeModal }, t("common.cancel"))),
  );
  openModal(t("issue.formTitle"), form);
}

// ---------------------------------------------------------------- Rezervasyonlarım ekleri
/* Rezervasyonlarım sayfasının ihtiyaç duyduğu veriler (paralel yüklenir). */
async function loadMyFeedback() {
  const [ratings, issues] = await Promise.all([api("/ratings/me"), api("/issues/me")]);
  return { rated: new Map(ratings.map((r) => [r.reservation_id, r.score])), issues };
}

/* Katılınmış rezervasyon için "Puan ver" düğmesi ya da verilmiş puan. Diğer durumlarda null. */
function ratingAction(r, feedback, reload) {
  if (!RATED_STATUSES.includes(r.status) || r.start_time > naive(new Date())) return null;
  const given = feedback.rated.get(r.id);
  if (given) return h("span", { class: "badge ok", title: t("rating.given") }, `★ ${given}`);
  return h("button", { class: "btn small", type: "button", onclick: () => openRatingForm(r, reload) }, `★ ${t("rating.rate")}`);
}

function myIssuesSection(feedback) {
  const items = feedback.issues.length
    ? feedback.issues.slice(0, 15).map((i) => h("div", { class: "list-item" },
      h("div", null,
        h("div", { class: "row" }, h("b", null, i.room_name || roomName(i.room_id)), issueBadge(i.status), badge(t(`issue.cat.${i.category}`))),
        h("div", { class: "small" }, i.description),
        h("div", { class: "muted small" }, fmtDateTime(i.created_at),
          i.resolution_note ? ` · ${t("issue.note")}: ${i.resolution_note}` : ""),
      )))
    : [h("p", { class: "muted" }, t("issue.noneMine"))];
  return h("section", { class: "card" }, h("h2", null, t("issue.mineTitle")), items);
}

// ---------------------------------------------------------------- Yönetim → Arızalar
async function adminIssues(body) {
  await loadAdminRooms();
  const roomSelect = h("select", { id: "i-room" }, selectOptions([["", t("ares.allRooms")], ...adminState.rooms.map((r) => [r.id, r.name])]));
  const statusSelect = h("select", { id: "i-status" },
    selectOptions([["", t("issue.allStatuses")], ["open", t("issue.status.open")], ["resolved", t("issue.status.resolved")]], "open"));
  const results = h("div");

  async function load() {
    const q = new URLSearchParams();
    if (roomSelect.value) q.set("room_id", roomSelect.value);
    if (statusSelect.value) q.set("status", statusSelect.value);
    results.replaceChildren(h("p", { class: "muted" }, t("app.loading")));
    try {
      const issues = await api(`/issues?${q}`);
      results.replaceChildren(issues.length
        ? rtable([
          { label: t("ares.col.id") }, { label: t("common.room") }, { label: t("issue.f.category") },
          { label: t("issue.f.description") }, { label: t("common.user") }, { label: t("issue.col.created") },
          { label: t("common.status") }, { label: t("common.actions") },
        ], issues.map((i) => [
          `#${i.id}`, i.room_name || adminRoomName(i.room_id), t(`issue.cat.${i.category}`),
          h("div", { class: "cell-wrap" }, i.description),
          i.user_name || "—", fmtDateTime(i.created_at),
          h("div", null, issueBadge(i.status),
            i.resolution_note && h("div", { class: "muted small" }, i.resolution_note),
            i.resolved_at && h("div", { class: "muted small" }, fmtDateTime(i.resolved_at))),
          i.status === "open"
            ? actionBtn(t("issue.resolve"), (ev) => resolve(i, ev.currentTarget), "btn small")
            : actionBtn(t("issue.reopen"), (ev) => reopen(i, ev.currentTarget)),
        ]), t("admin.tab.issues"))
        : h("p", { class: "muted" }, t("issue.emptyAdmin")));
    } catch (err) { results.replaceChildren(errorBox(err)); }
  }

  const resolve = async (issue, button) => {
    const note = h("textarea", { id: "issue-note", maxlength: 500, rows: 2, placeholder: t("issue.notePlaceholder") });
    const ok = await confirmModal(t("issue.resolveTitle"),
      t("issue.resolveAsk", { room: issue.room_name, cat: t(`issue.cat.${issue.category}`) }), t("issue.resolve"),
      h("div", null, h("label", { for: "issue-note" }, t("issue.note")), note), "btn");
    if (!ok) return;
    await busy(button, async () => {
      await api(`/issues/${issue.id}`, { method: "PATCH", json: { status: "resolved", resolution_note: note.value } });
      toast(t("issue.resolved"));
      load();
    });
  };
  const reopen = async (issue, button) => busy(button, async () => {
    await api(`/issues/${issue.id}`, { method: "PATCH", json: { status: "open" } });
    toast(t("issue.reopened"));
    load();
  });

  roomSelect.addEventListener("change", load);
  statusSelect.addEventListener("change", load);
  body.replaceChildren(
    h("div", { class: "card row" }, labeled("i-room", t("common.room"), roomSelect), labeled("i-status", t("common.status"), statusSelect)),
    h("section", { class: "card" }, results),
  );
  await load();
}
