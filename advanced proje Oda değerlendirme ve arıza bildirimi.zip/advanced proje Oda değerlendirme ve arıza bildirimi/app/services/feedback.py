"""Oda değerlendirme ve arıza bildirimi: iş kuralları.

Kurallar
- Puan yalnızca öğrencinin kendisine ait ve gerçekten katıldığı (check-in yapılmış) rezervasyona verilir.
  Rezervasyon başlamadan puan verilemez; her rezervasyon bir kez puanlanır.
- Arıza herhangi bir oda için bildirilebilir. Aynı öğrenci, aynı odada aynı türde açık bir bildirim
  varken ikinci kez bildiremez (mükerrer kaydı önler).
- Admin bildirimi çözüldü olarak işaretleyince bildiren öğrenciye e-posta gider; gerekirse yeniden açabilir.
"""
from collections import Counter
from datetime import datetime

from sqlmodel import Session, col, func, select

from app.models import (
    IssueReport,
    IssueStatus,
    Reservation,
    ReservationStatus,
    Role,
    Room,
    RoomRating,
    User,
)
from app.schemas import IssueRead, RoomRatingSummary, RoomReview, RoomReviews
from app.services.notifications import notify
from app.services.reservation_service import BookingError

# Puan verilebilmesi için öğrencinin odaya gelmiş olması gerekir
ATTENDED = (ReservationStatus.checked_in, ReservationStatus.completed)

CATEGORY_TR = {
    "equipment": "Ekipman", "power": "Elektrik / aydınlatma", "cleanliness": "Temizlik",
    "furniture": "Masa / sandalye", "noise": "Gürültü", "other": "Diğer",
}


# ---------------------------------------------------------------- Puanlama
def rate(session: Session, user: User, reservation_id: int, score: int, comment: str, now: datetime) -> RoomRating:
    reservation = session.get(Reservation, reservation_id)
    if reservation is None:
        raise BookingError("reservation_not_found", "Rezervasyon bulunamadı", 404)
    if reservation.user_id != user.id:
        raise BookingError("forbidden", "Bu rezervasyon size ait değil", 403)
    if reservation.status not in ATTENDED or reservation.start_time > now:
        raise BookingError("not_attended", "Yalnızca katıldığınız (check-in yaptığınız) rezervasyonları puanlayabilirsiniz", 409)
    if session.exec(select(RoomRating).where(RoomRating.reservation_id == reservation_id)).first():
        raise BookingError("already_rated", "Bu rezervasyonu zaten puanladınız", 409)
    rating = RoomRating(
        reservation_id=reservation.id, user_id=user.id, room_id=reservation.room_id,
        score=score, comment=comment.strip(), created_at=now,
    )
    session.add(rating)
    session.commit()
    session.refresh(rating)
    return rating


def my_ratings(session: Session, user: User) -> list[RoomRating]:
    stmt = select(RoomRating).where(RoomRating.user_id == user.id).order_by(col(RoomRating.created_at).desc())
    return list(session.exec(stmt).all())


def _open_issue_counts(session: Session) -> Counter:
    stmt = (
        select(IssueReport.room_id, func.count())
        .where(IssueReport.status == IssueStatus.open)
        .group_by(IssueReport.room_id)
    )
    return Counter(dict(session.exec(stmt).all()))


def _summary(room_id: int, scores: list[int], open_issues: int) -> dict:
    counts = Counter(scores)
    return {
        "room_id": room_id,
        "average": round(sum(scores) / len(scores), 2) if scores else None,
        "count": len(scores),
        "distribution": {s: counts.get(s, 0) for s in range(5, 0, -1)},
        "open_issues": open_issues,
    }


def summaries(session: Session) -> list[RoomRatingSummary]:
    """Tüm odaların puan özeti (oda kartlarında tek istekle gösterilir)."""
    scores: dict[int, list[int]] = {}
    for room_id, score in session.exec(select(RoomRating.room_id, RoomRating.score)).all():
        scores.setdefault(room_id, []).append(score)
    issues = _open_issue_counts(session)
    rooms = session.exec(select(Room.id).order_by(Room.id)).all()
    return [RoomRatingSummary(**_summary(rid, scores.get(rid, []), issues.get(rid, 0))) for rid in rooms]


def room_reviews(session: Session, room: Room, limit: int = 5) -> RoomReviews:
    ratings = session.exec(
        select(RoomRating).where(RoomRating.room_id == room.id).order_by(col(RoomRating.created_at).desc())
    ).all()
    open_issues = _open_issue_counts(session).get(room.id, 0)
    # Yalnızca yorumlu puanlar listelenir; ortalama tüm puanlardan hesaplanır
    reviews = [RoomReview(score=r.score, comment=r.comment, created_at=r.created_at) for r in ratings if r.comment][:limit]
    return RoomReviews(**_summary(room.id, [r.score for r in ratings], open_issues), reviews=reviews)


# ---------------------------------------------------------------- Arıza bildirimi
def report_issue(
    session: Session, user: User, room_id: int, category, description: str, reservation_id: int | None, now: datetime
) -> IssueReport:
    room = session.get(Room, room_id)
    if room is None:
        raise BookingError("room_not_found", "Oda bulunamadı", 404)
    if reservation_id is not None:
        reservation = session.get(Reservation, reservation_id)
        if reservation is None or reservation.user_id != user.id or reservation.room_id != room_id:
            raise BookingError("forbidden", "Bu rezervasyon size ait değil ya da bu odaya ait değil", 403)
    duplicate = session.exec(
        select(IssueReport).where(
            IssueReport.room_id == room_id,
            IssueReport.user_id == user.id,
            IssueReport.category == category,
            IssueReport.status == IssueStatus.open,
        )
    ).first()
    if duplicate:
        raise BookingError(
            "duplicate_issue", "Bu oda için aynı türde açık bir bildiriminiz zaten var", 409, {"issue_id": duplicate.id}
        )
    issue = IssueReport(
        room_id=room_id, user_id=user.id, reservation_id=reservation_id, category=category,
        description=description.strip(), created_at=now,
    )
    session.add(issue)
    session.commit()
    session.refresh(issue)
    return issue


def update_issue(session: Session, issue: IssueReport, admin: User, status: IssueStatus, note: str | None, now: datetime) -> IssueReport:
    if issue.status == status:
        raise BookingError("issue_unchanged", "Bildirim zaten bu durumda", 409)
    issue.status = status
    if status == IssueStatus.resolved:
        issue.resolved_at, issue.resolved_by = now, admin.id
        issue.resolution_note = (note or "").strip() or None
        reporter = session.get(User, issue.user_id)
        room = session.get(Room, issue.room_id)
        notify(
            session,
            reporter,
            "StudySpot: Arıza bildiriminiz çözüldü",
            f"{room.name} için bildirdiğiniz sorun ({CATEGORY_TR[issue.category.value]}) çözüldü olarak işaretlendi."
            + (f" Not: {issue.resolution_note}" if issue.resolution_note else "")
            + " Teşekkür ederiz!",
            "issue_resolved",
        )
    else:  # yeniden açıldı
        issue.resolved_at = issue.resolved_by = issue.resolution_note = None
    session.add(issue)
    session.commit()
    session.refresh(issue)
    return issue


def list_issues(session: Session, user: User | None = None, status: IssueStatus | None = None,
                room_id: int | None = None) -> list[IssueReport]:
    """`user` verilirse yalnızca onun bildirimleri; açıklar önce, sonra en yeniler."""
    stmt = select(IssueReport)
    if user is not None:
        stmt = stmt.where(IssueReport.user_id == user.id)
    if status is not None:
        stmt = stmt.where(IssueReport.status == status)
    if room_id is not None:
        stmt = stmt.where(IssueReport.room_id == room_id)
    rows = session.exec(stmt).all()
    return sorted(rows, key=lambda i: (i.status != IssueStatus.open, -i.created_at.timestamp(), -i.id))


def to_read(session: Session, issue: IssueReport, viewer: User) -> IssueRead:
    room = session.get(Room, issue.room_id)
    data = {"room_name": room.name if room else None}
    # Bildireni yalnızca admin görür
    if viewer.role == Role.admin:
        reporter = session.get(User, issue.user_id)
        data["user_name"] = reporter.full_name if reporter else None
    return IssueRead.model_validate(issue).model_copy(update=data)
