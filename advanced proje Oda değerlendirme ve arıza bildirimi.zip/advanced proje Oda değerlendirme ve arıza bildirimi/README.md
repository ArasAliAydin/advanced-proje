# StudySpot — Çalışma Salonu / Oda Rezervasyon Sistemi

Haliç Üniversitesi · CEN 3001 Advanced Computer Programming · Grup Projesi

Kütüphane odaları, laboratuvarlar ve çalışma salonları için saat bazlı rezervasyon platformu: REST API ve aynı API'yi kullanan web arayüzü.

> **v2:** **web arayüzü** ve **akıllı slot önerisi** eklendi. Geliştirme `v2` dalında yapılır; sunum demosu `main` dalında sabit kalır.
> Demo ve geliştirme kopyası aynı makinede 8000 ve 8001 portlarında birlikte çalışabilir (bkz. [Docker](#docker)).

> **v3:** web arayüzüne **Yönetim ekranları** (oda ekle/düzenle/kapat, kullanıcı rol/durum/ceza, filtreli tüm rezervasyonlar ve admin iptali, tüm bekleme listesi, CSV indirme, resmi tatiller), koltuk bazlı salonlar için **koltuk haritası**, **Türkçe / İngilizce** dil seçimi ve **gece / gündüz modu** eklendi. Geliştirme `v3` dalında, Docker'da `studyspot-v3` adıyla 8002 portunda (bkz. [v3'te yenilikler](#v3te-yenilikler)).

> **Oda değerlendirme ve arıza bildirimi:** öğrenciler katıldıkları rezervasyondan sonra odaya **1–5 puan ve yorum** verir, odadaki sorunları **arıza bildirimi** olarak iletir; admin *Yönetim → Arızalar*'da çözüldü olarak işaretler ve bildirene e-posta gider. Oda kartlarında ortalama puan ve açık arıza rozeti görünür. Bu kopya oda favorileri sürümünün üzerine kuruludur; Docker'da `studyspot-degerlendirme` adıyla **8004** portunda (bkz. [Oda değerlendirme ve arıza bildirimi](#oda-değerlendirme-ve-arıza-bildirimi)).

| Ortak altyapı gereksinimi | Bu projede |
|---|---|
| FastAPI + SQLModel + SQLite, Python 3.12 | `app/` — 50 endpoint, 9 tablo |
| JWT auth + rol bazlı yetkilendirme | `student` / `admin` rolleri, OAuth2 password flow |
| Pytest | `tests/` — 101 test |
| Docker | `Dockerfile`, `docker-compose.yml` |
| **Gerçek bir algoritma** | Sweep-line ile çakışma/kapasite tespiti, FIFO bekleme listesi ve otomatik atama, çok kriterli skorla akıllı slot önerisi |
| Web arayüzü | `app/static/` — HTML/CSS/vanilla JS, derleme adımı yok, FastAPI'den sunulur; TR/EN, gece/gündüz modu |
| **Harici API** | Resmi tatiller ([date.nager.at](https://date.nager.at)), DB'de önbellekli, fail-open |
| **Arka plan görevi** | Dakikada bir: no-show iptali + ceza, hatırlatma e-postası, tamamlama, sıra temizliği |

## Özellikler

- **Odalar:** iki rezervasyon modu — `exclusive` (oda tek rezervasyona kapanır) ve `shared` (koltuk bazlı, aynı anda `capacity` kadar kişi; her rezervasyon bir koltuğa oturur). Açılış/kapanış saati ve slot uzunluğu oda bazında. Oda kapatılınca (pasife alınınca) henüz başlamamış rezervasyonları cezasız iptal edilir ve sahiplerine e-posta gider.
- **Rezervasyon:** çakışma kontrolü, slot hizalama, çalışma saatleri, tek seferde en fazla 3 saat, en fazla 14 gün ileri, resmi tatilde kapalı.
- **Müsaitlik:** müsaitlik sorguları rezervasyon kurallarıyla tutarlıdır; tatil günleri, geçmiş ve 14 gün ötesi müsait görünmez, slotun `reason` alanı nedenini söyler (`holiday`, `in_past`, `too_far`, `slot_full`, `room_inactive`).
- **Limitler:** öğrenci başına günlük 4, haftalık 12 saat (admin muaf).
- **Bekleme listesi:** dolu slot için sıraya girilir; iptal veya no-show olunca sıradaki *uygun* kişiye rezervasyon otomatik açılır ve e-posta gider.
- **Akıllı slot önerisi:** istenen slot doluysa aynı odada aynı gün en yakın boş aralıklar (aynı süre) ve aynı saatte uygun diğer odalar önerilir. Her öneri gerçek rezervasyon kurallarından geçmiştir (saat, limit, çakışma, kalan koltuk); skor zaman yakınlığı + oda tipi/kapasite uyumu + geçmiş doluluğa (sakinlik) göredir. `409 slot_full` yanıtı önerileri `suggestions` alanında taşır. Odanın en sakin saatleri ayrıca sorgulanabilir.
- **Web arayüzü:** giriş/kayıt, oda ve gün seçerek slot tablosu, boş slota tıklayıp rezervasyon, dolu slotta öneriler (tek tıkla rezervasyon) ve bekleme listesi; Rezervasyonlarım (iptal, QR, `.ics`, sıra numaraları); admin için özet rapor, gün × saat ısı haritası, oda istatistikleri, e-posta günlüğü ve "görevleri şimdi çalıştır". İş kuralı hataları kodlarına göre başlık ve ipucuyla gösterilir; telefon genişliğinde de kullanılır. v3'te Yönetim ekranları, koltuk haritası, TR/EN ve gece/gündüz modu eklendi (bkz. [v3'te yenilikler](#v3te-yenilikler)).
- **Koltuk haritası (v3):** koltuk bazlı salonlarda öğrenci rezervasyon penceresinde koltuğunu haritadan seçer (`seat_number`); seçmezse aralığın tamamında boş olan ilk koltuk atanır. Harita sıra düzeni odanın `seats_per_row` alanından gelir. Bir rezervasyon süresi boyunca tek koltukta kalır: 10–11'de 1 numara, 11–12'de 2 numara doluysa 10–12 için kesintisiz boş koltuk yoktur ve slot dolu sayılır. Bekleme listesinden atananlara da boş koltuk verilir. Exclusive odalarda koltuk seçilmez.
- **QR check-in:** her rezervasyonun QR kodu (PNG) vardır. Başlangıçtan 10 dk önce açılır, 15 dk sonra kapanır (slotun bitişini aşamaz).
- **Ceza sistemi:** no-show 2 puan, geç iptal (son 30 dk) 1 puan; 6 puanda 7 gün rezervasyon yasağı. Başlangıca 30 dk veya daha az kala (ya da slot başladıktan sonra) bekleme listesinden atanan rezervasyon ceza doğurmaz: kişinin cezasız iptal etme fırsatı hiç olmamıştır.
- **Analitik:** gün × saat doluluk ısı haritası, saatlik/günlük yoğunluk, oda istatistikleri, özet rapor, CSV dışa aktarma.
- **Takvim:** tek rezervasyon veya tüm yaklaşanlar için `.ics` (Google Calendar / Outlook).
- **E-posta:** onay, hatırlatma, iptal, sıradan atama, yasak bildirimleri. Varsayılan `console` modunda gönderilmez, `EmailLog` tablosuna yazılır (`GET /admin/emails`); SMTP ayarlanırsa gerçekten gönderilir.

Tüm kural değerleri `.env` ile değiştirilebilir (bkz. `.env.example`).

## Çalıştırma

### Yerel

```bash
python -m venv .venv
.venv\Scripts\activate            # Linux/macOS: source .venv/bin/activate
pip install -r requirements-dev.txt
copy .env.example .env            # SECRET_KEY'i değiştirin (varsayılan anahtarla açılışta uyarı loglanır)
python -m scripts.seed            # isteğe bağlı: demo verisi
uvicorn app.main:app --reload
```

Web arayüzü: <http://127.0.0.1:8000/> · Swagger arayüzü: <http://127.0.0.1:8000/docs>

İlk açılışta `.env` içindeki `ADMIN_EMAIL` / `ADMIN_PASSWORD` ile bir admin hesabı oluşturulur (varsayılanlar `.env.example` içinde). Web arayüzünde bu bilgilerle giriş yapınca **Yönetim** sekmesi açılır; Swagger'da **Authorize** düğmesine e-posta ve şifreyi yazmak yeterli.

### Docker

```bash
docker compose up --build
```

Web arayüzü <http://localhost:8000>, Swagger <http://localhost:8000/docs> adresinde açılır; Docker Desktop'ta `studyspot-v1` adıyla görünür. Veritabanı `studyspot-v1_studyspot-data` volume'ünde kalıcıdır. Demo verisi için: `docker compose exec api python -m scripts.seed` (sıfırdan: `--reset`)

**Aynı makinede iki kopya (demo + geliştirme).** Proje adı ve port `docker-compose.yml` içinde değişkendir, böylece dosya her dalda aynı kalır. Geliştirme kopyasının klasöründe `.env` dosyasına şunları eklemek yeterli:

```
COMPOSE_PROJECT_NAME=studyspot-v2
STUDYSPOT_PORT=8001
```

Bu kopya <http://localhost:8001> adresinde, `studyspot-v2` adıyla ve kendi volume'üyle (`studyspot-v2_studyspot-data`) çalışır; 8000'deki demo etkilenmez. v3 kopyası aynı şekilde `COMPOSE_PROJECT_NAME=studyspot-v3`, `STUDYSPOT_PORT=8002` ile <http://localhost:8002> adresinde çalışır.

### Testler

```bash
pytest
```

Testler bellek içi SQLite kullanır, zamanı sabitler (`clock.freeze`) ve harici API'yi taklit eder; internet gerektirmez.

Python 3.12 Docker imajında (`tests/` imaja kopyalanmaz, volume ile bağlanır; Windows PowerShell örneği):

```powershell
docker compose build
docker run --rm -u root -v "${PWD}/tests:/app/tests:ro" -v "${PWD}/pytest.ini:/app/pytest.ini:ro" studyspot-v3-api sh -c "pip install -q pytest==9.2.0 && python -m pytest -q -p no:cacheprovider"
```

## Mimari

```
app/
├── main.py                  # uygulama, lifespan (tablolar, admin, zamanlayıcı), hata handler'ı
├── models.py                # SQLModel tabloları
├── schemas.py               # istek/yanıt şemaları
├── core/
│   ├── config.py            # ayarlar (.env)
│   ├── database.py          # engine, oturum
│   ├── security.py          # bcrypt, JWT
│   ├── deps.py              # CurrentUser, AdminUser bağımlılıkları
│   └── clock.py             # tek zaman kaynağı (testte dondurulabilir)
├── static/                  # WEB ARAYÜZÜ: index.html, style.css, app.js (derleme yok)
├── routers/                 # ince HTTP katmanı: auth, rooms, reservations, waitlist, suggestions, analytics, admin
└── services/                # iş mantığı
    ├── scheduling.py        # ALGORİTMA: overlaps, peak_concurrency (sweep-line), hour_buckets
    ├── reservation_service.py  # kurallar, limitler, iptal, check-in
    ├── waitlist_service.py  # ALGORİTMA: FIFO sıra + otomatik atama
    ├── suggestions.py       # ALGORİTMA: akıllı slot önerisi (aday üret, kurallarla ele, skorla), sakin saatler
    ├── penalties.py         # ceza puanı, yasak
    ├── jobs.py              # ARKA PLAN GÖREVLERİ
    ├── holidays.py          # HARİCİ API + önbellek
    ├── notifications.py     # e-posta
    ├── exports.py           # .ics, QR
    └── analytics.py         # doluluk hesapları
```

### Algoritmalar

**Çakışma / kapasite tespiti** (`services/scheduling.py`). Aralıklar yarı açıktır `[başlangıç, bitiş)`. Koltuk bazlı salonlarda yalnızca çakışan rezervasyonları saymak yanlış sonuç verir: 10–11 ve 11–12 rezervasyonları 10–12 isteğiyle çakışır ama aynı koltuğu art arda kullanır. Bu yüzden istenen pencere içindeki **en yüksek eşzamanlı doluluk** sweep-line ile bulunur (olayları sırala, +1/−1 topla; O(n log n)). `kalan = kapasite − tepe`.

**Bekleme listesi ataması** (`services/waitlist_service.py`). Slot boşalınca o aralıkla kesişen bekleyenler kayıt sırasına göre gezilir; her aday için tüm rezervasyon kuralları yeniden doğrulanır. Uymayan (limiti dolmuş, cezalı, o saate başka yer bulmuş) atlanır ve sırada kalır. Böylece boşalan 2 saatlik slot, 1'er saat bekleyen iki kişiye de dağıtılabilir.

**Akıllı slot önerisi** (`services/suggestions.py`). Üç adım:

1. *Aday üret:* aynı odada aynı gün, odanın slot ızgarasına hizalı ve istenenle aynı süredeki tüm başlangıçlar + aynı saat aralığında diğer aktif odalar.
2. *Kurallarla ele:* her aday rezervasyonda kullanılan fonksiyonlardan geçer (`validate_time_rules`, `ensure_no_user_conflict`, `ensure_within_limits`, `remaining_seats`). Yani önerilen her slot o an gerçekten alınabilir; limiti dolmuş öğrenciye o gün için öneri çıkmaz.
3. *Skorla ve sırala* (her bileşen 0..1):

| Bileşen | Formül | Varsayılan ağırlık |
|---|---|---|
| Yakınlık | `max(0, 1 − \|Δt\| / 6 saat)` | 0.5 |
| Oda uyumu | `½·tip + ½·min(c₁,c₂)/max(c₁,c₂)` — tip: aynı `room_type` 1, yalnızca aynı `booking_mode` 0.5; aynı oda 1 | 0.3 |
| Sakinlik | `1 − geçmiş doluluk` — son 28 gün, haftanın aynı günü ve saatleri (analitikle aynı hesap) | 0.2 |

`skor = Σ wᵢ·bileşenᵢ / Σ wᵢ`. Eşit skorda istenen saate yakın olan, sonra aynı oda önce gelir. Ağırlıklar, ufuk ve geçmiş penceresi `.env` ile değişir (`SUGGEST_WEIGHT_PROXIMITY`, `SUGGEST_WEIGHT_FIT`, `SUGGEST_WEIGHT_QUIET`, `SUGGEST_HORIZON_HOURS`, `SUGGEST_HISTORY_DAYS`, `SUGGEST_LIMIT`). Yakınlık en ağır basar çünkü öğrenci büyük olasılıkla o saate göre plan yapmıştır; oda uyumu ikinci gelir çünkü 6 kişilik bir grup için tek koltuk işe yaramaz; sakinlik eşitlik bozucu gibi çalışıp kalabalık saatlerden uzaklaştırır. Her önerinin yanıtında bileşen puanları ve Türkçe gerekçeler (`reasons`) bulunur.

**Eşzamanlılık.** "Kontrol et → kaydet" adımı `booking_lock` altında çalışır; iki istek aynı anda son koltuğu alamaz (tek süreçli SQLite kurulumu için yeterli).

### Veritabanı şeması

| Tablo | Önemli alanlar |
|---|---|
| `user` | email (unique), hashed_password, role, is_active, penalty_points, banned_until |
| `room` | name (unique), room_type, booking_mode, capacity, open_time, close_time, slot_minutes, seats_per_row, is_active |
| `reservation` | user_id → user, room_id → room, start_time, end_time, seat_number, status, source, checkin_code (unique), checked_in_at, reminder_sent |
| `waitlistentry` | user_id, room_id, start_time, end_time, status, promoted_reservation_id → reservation |
| `penaltylog` | user_id, reservation_id, points, reason |
| `emaillog` | user_id, to_email, subject, body, kind, status |
| `holiday` | day (unique), year, name |

Rezervasyon durumları: `confirmed → checked_in → completed`, `confirmed → cancelled`, `confirmed → no_show`.
Zamanlar kampüs yerel saatinde (`TIMEZONE`) tz'siz saklanır; tz'li girişler otomatik çevrilir.
v3'te eklenen `seats_per_row` ve `seat_number` kolonları, v1/v2'den kalan bir SQLite dosyasına açılışta otomatik eklenir (`core/database.py` → `add_missing_columns`); eski rezervasyonların koltuk numarası boş kalır ve herhangi bir koltuğu tutuyor sayılır.

## Endpoint listesi

Tümü `/api/v1` altında. 🔒 = giriş gerekli, 👑 = yalnızca admin.

| Metot | Yol | Açıklama |
|---|---|---|
| POST | `/auth/register` | Öğrenci kaydı |
| POST | `/auth/login` | JWT al (form: username = e-posta) |
| GET | `/auth/me` 🔒 | Profil, ceza puanı |
| GET | `/auth/me/penalties` 🔒 | Ceza geçmişim |
| GET | `/rooms` 🔒 | Oda listesi (tip, kapasite filtresi) |
| GET | `/rooms/available` 🔒 | Verilen aralıkta müsait odalar |
| GET | `/rooms/{id}` 🔒 | Oda detayı |
| GET | `/rooms/{id}/availability?day=` 🔒 | Günün slotları, kalan yer, müsait değilse nedeni |
| GET | `/rooms/{id}/quiet-hours?weekday=&limit=` 🔒 | Geçmiş doluluğa göre odanın en sakin saatleri |
| GET | `/rooms/{id}/seats?start_time=&end_time=` 🔒 | Koltuk haritası: aralıkta boş / dolu / benim koltuklarım (yalnızca `shared`) |
| GET | `/suggestions?room_id=&start_time=&end_time=&limit=` 🔒 | Dolu slot yerine kurallara uyan alternatifler (skorlu) |
| POST / PATCH / DELETE | `/rooms`, `/rooms/{id}` 👑 | Oda yönetimi (silme = pasife alma + yaklaşan rezervasyonların iptali) |
| POST | `/reservations` 🔒 | Rezervasyon yap; `shared` odada isteğe bağlı `seat_number` (dolu slotta 409 + `suggestions`) |
| GET | `/reservations/me` 🔒 | Rezervasyonlarım |
| GET | `/reservations/me/calendar.ics` 🔒 | Yaklaşanlar, takvim dosyası |
| GET | `/reservations/{id}` 🔒 | Detay (sahibi veya admin) |
| DELETE | `/reservations/{id}` 🔒 | İptal + sıradakine atama |
| GET | `/reservations/{id}/qr` 🔒 | Check-in QR kodu (PNG) |
| GET | `/reservations/{id}/ics` 🔒 | Takvim dosyası |
| GET | `/reservations` 👑 | Tüm rezervasyonlar (filtreli) |
| POST | `/checkin` 🔒 | QR koduyla check-in |
| POST | `/waitlist` 🔒 | Dolu slot için sıraya gir |
| GET | `/waitlist/me` 🔒 | Sıra kayıtlarım (pozisyonla) |
| DELETE | `/waitlist/{id}` 🔒 | Sıradan çık |
| GET | `/waitlist` 👑 | Tüm sıra kayıtları |
| GET | `/analytics/occupancy/heatmap` 🔒 | Gün × saat doluluk |
| GET | `/analytics/occupancy/hourly` 🔒 | Saatlik yoğunluk |
| GET | `/analytics/occupancy/daily` 🔒 | Günlük yoğunluk |
| GET | `/analytics/rooms` 👑 | Oda istatistikleri |
| GET | `/analytics/summary` 👑 | Özet rapor |
| GET | `/admin/users` 👑 | Kullanıcılar |
| PATCH | `/admin/users/{id}` 👑 | Rol / aktiflik |
| POST | `/admin/users/{id}/reset-penalty` 👑 | Ceza ve yasağı kaldır |
| GET | `/admin/penalties` 👑 | Ceza kayıtları |
| GET | `/admin/emails` 👑 | Bildirim günlüğü |
| POST | `/admin/jobs/run` 👑 | Zamanlanmış görevleri hemen çalıştır |
| GET | `/admin/holidays/{year}` 👑 | Önbellekteki resmi tatiller |
| GET | `/admin/reports/reservations.csv` 👑 | CSV rapor |

Bunlara ek olarak `/` web arayüzünü, `/docs` Swagger'ı, `/health` sağlık kontrolünü döndürür.

İş kuralı hataları `{"detail": "...", "code": "slot_full"}` biçiminde döner (`slot_full` yanıtında ayrıca `suggestions` listesi bulunur). Kodlar: `slot_full`, `seat_taken`, `invalid_seat`, `seat_not_applicable`, `user_conflict`, `daily_limit`, `weekly_limit`, `outside_hours`, `slot_misaligned`, `too_long`, `in_past`, `too_far`, `holiday`, `user_banned`, `room_inactive`, `too_early`, `too_late`, `already_started` …
Mesajında değer geçen hatalar bu değerleri ayrıca `params` alanında taşır (ör. `outside_hours` → `{"open": "08:00", "close": "22:00"}`); İngilizce arayüz mesajı koddan ve bu parametrelerden kendisi kurar.

## v3'te yenilikler

**Yönetim sekmesi** (`#/admin/<bölüm>`, `app/static/admin.js`). Sunucu tarafında yeni yönetim endpoint'i gerekmedi; ekranlar mevcut API'leri kullanır. Silme, kapatma, rol/durum değiştirme, ceza sıfırlama ve iptal gibi işlemler onay penceresi ister. Telefonda tablolar karta dönüşür.

| Bölüm | Ne yapılır | Kullandığı API |
|---|---|---|
| Rapor | v2'deki özet, ısı haritası, oda istatistikleri, e-posta günlüğü, görevleri çalıştır | `/analytics/*`, `/admin/emails`, `/admin/jobs/run` |
| Odalar | Açık/kapalı tüm odalar; **ekle**, **düzenle** (ad, konum, tip, mod, kapasite / koltuk sayısı, sıra başına koltuk, saatler, slot 15–240 dk), **kapat** (kaç rezervasyonun iptal edileceği önceden söylenir), **geri aç**. 409 isim çakışması ve 422 doğrulama hataları ilgili alanın altında gösterilir | `GET /rooms?include_inactive=true`, `POST /rooms`, `PATCH /rooms/{id}`, `DELETE /rooms/{id}` |
| Kullanıcılar | Arama; rol, durum, **ceza puanı** ve **yasak bitişi**; admin/öğrenci yap, pasif/aktif yap, cezayı sıfırla, kişinin ceza kayıtları; tüm ceza kayıtları. Admin kendi rolünü/durumunu değiştiremez (arayüzde de kilitli) | `/admin/users`, `/admin/users/{id}`, `/admin/users/{id}/reset-penalty`, `/admin/penalties` |
| Rezervasyonlar | Oda, kullanıcı, durum ve tarih aralığı filtresi; sayfalama; isteğe bağlı nedenle **admin iptali** (cezasız, kullanıcıya e-posta, slot bekleme listesine açılır); **CSV indir** (JWT ile fetch edilip dosya olarak kaydedilir) | `GET /reservations`, `DELETE /reservations/{id}?reason=`, `/admin/reports/reservations.csv` |
| Bekleme listesi | Oda ve durum filtresi, sıra numarası, atanan rezervasyon; bekleyen kaydı sıradan çıkarma | `GET /waitlist`, `DELETE /waitlist/{id}` |
| Tatiller | Yıl seçerek harici API'den gelen resmi tatiller | `/admin/holidays/{yıl}` |

**Koltuk haritası.** Koltuk bazlı bir salonda boş slota tıklayınca rezervasyon penceresinde koltuklar sıra düzeniyle çizilir: yeşil boş, gri dolu, mor sizin. Süre değişince harita yeniden yüklenir; seçilen koltuk o sırada doluysa sunucu `409 seat_taken` döner ve harita tazelenir. Demo verisinde *Sessiz Çalışma Salonu* 24 koltuk (8'li sıralar), *Bilgisayar Lab A* 12 koltuk (4'lü sıralar).

**Dil ve tema.** Üst çubuktaki **EN / TR** düğmesi arayüz dilini, **☾ / ☀** düğmesi gece/gündüz modunu değiştirir; seçim tarayıcıda hatırlanır. İlk açılışta tarayıcı dili ve sistemin koyu tema ayarı kullanılır. Metinler `app/static/i18n.js` içinde `[Türkçe, İngilizce]` çiftleri olarak durur; sunucu iş kuralı mesajlarını Türkçe döndürmeye devam eder, İngilizce arayüz bunları hata kodu ve `params` alanından çevirir.

## Oda değerlendirme ve arıza bildirimi

Sunucu: `app/services/feedback.py` (iş kuralları), `app/routers/feedback.py` (endpoint'ler), `models.py`'de `RoomRating` ve `IssueReport` tabloları. Arayüz: `app/static/feedback.js` (oda kartı rozetleri, oda sayfasındaki değerlendirmeler, puan verme ve arıza bildirme pencereleri, Rezervasyonlarım ekleri, *Yönetim → Arızalar*). Testler: `tests/test_feedback.py`.

**İş kuralları**

- Puan yalnızca **kendi** ve **katıldığınız** (check-in yapılmış: `checked_in` / `completed`) rezervasyona verilir; başlamamış, iptal edilmiş veya gelinmemiş (`no_show`) rezervasyon `409 not_attended`.
- Her rezervasyon **bir kez** puanlanır (`409 already_rated`, veritabanında `reservation_id` tekil). Puan 1–5, yorum en fazla 500 karakter.
- Oda sayfasındaki yorumlarda yorumu yazanın kimliği **gösterilmez**; ortalama tüm puanlardan, liste yalnızca yorumlu puanlardan oluşur.
- Arıza her oda için bildirilebilir (açıklama 5–500 karakter). Aynı öğrenci aynı odada **aynı türde açık bir bildirimi** varken tekrar bildiremez (`409 duplicate_issue`, yanıtta mevcut `issue_id`); çözüldükten sonra yeniden bildirebilir. Rezervasyon iliştirilirse kendisine ve o odaya ait olmalı.
- Admin bildirimi **çözüldü** yapınca (isteğe bağlı notla) bildiren öğrenciye e-posta gider (`issue_resolved`); gerekirse **yeniden açar**. Bildireni yalnızca admin görür.

| Metot | Yol | Açıklama |
|---|---|---|
| POST | `/ratings` 🔒 | Katılınan rezervasyona puan + yorum |
| GET | `/ratings/me` 🔒 | Verdiğim puanlar |
| GET | `/ratings/summary` 🔒 | Tüm odaların ortalama puanı, sayısı, dağılımı, açık arıza sayısı |
| GET | `/ratings/rooms/{id}` 🔒 | Odanın puan özeti ve son yorumları |
| POST | `/issues` 🔒 | Arıza bildir |
| GET | `/issues/me` 🔒 | Bildirimlerim |
| GET | `/issues` 👑 | Tüm bildirimler (durum ve oda filtresi; açıklar önce) |
| PATCH | `/issues/{id}` 👑 | Çözüldü / yeniden aç |

Demo verisi (`python -m scripts.seed --reset`) geçmiş tamamlanmış rezervasyonların yaklaşık %20'sine oda başına farklı eğilimde puan (Bilgisayar Lab A düşük, Sessiz Çalışma Salonu yüksek) ve 3 arıza bildirimi (2 açık, 1 çözülmüş) ekler.

## Sunum için demo senaryosu

`python -m scripts.seed --reset` sonrası web arayüzünden (<http://localhost:8000>; geliştirme kopyalarında 8001 / 8002). Öğrenci hesapları `ogrenci1..6@example.com` (şifre `scripts/seed.py` içinde), admin bilgileri `.env.example` içinde. İki öğrenciyi aynı anda göstermek için ikinci bir tarayıcı penceresi (gizli pencere) kullanılabilir.

1. **Admin** ile giriş → **Yönetim**: özet rapor, gün × saat **ısı haritası** (3 haftalık geçmiş veri; öğlen saatleri koyu), oda istatistikleri.
2. **ogrenci1** ile giriş → **Odalar** → *Grup Odası 1* → yarın → boş 10:00 slotuna tıkla → süre 2 saat → **Rezerve et** → **QR kodunu göster** / **Takvime ekle (.ics)**. Slot tablosunda mor "Rezervasyonunuz" olarak görünür; altta günün **en sakin saatleri** listelenir.
3. **ogrenci2** ile aynı odada aynı güne gir → kırmızı **Dolu** 10:00 slotuna tıkla → **akıllı öneriler**: aynı odada en yakın boş saatler ve aynı saatte uygun diğer odalar, uygunluk yüzdesi ve gerekçeleriyle → birinde **Rezerve et** (tek tık).
4. ogrenci2 dolu 11:00 slotunda **Bekleme listesine katıl** → *Rezervasyonlarım*'da "1. sıra".
5. ogrenci1 → *Rezervasyonlarım* → 10–12 rezervasyonunu **İptal et** → ogrenci2'ye 11–12 slotu **otomatik atanır** (`Bekleme listesinden` rozeti); admin **E-posta günlüğü**'nde bildirimi gösterir.
6. No-show: 15 dakikadan önce başlamış, check-in yapılmamış bir rezervasyon varken admin **Görevleri şimdi çalıştır** → durum `no_show`, kullanıcıya +2 ceza puanı. (Sunumda beklememek için `.env` içinde `CHECKIN_GRACE_MINUTES=1` yapılabilir.)
7. **(v3) Koltuk haritası:** ogrenci3 → *Sessiz Çalışma Salonu* → yarın boş bir slot → haritadan bir koltuk seç → **Rezerve et**; Rezervasyonlarım'da ve QR penceresinde "Koltuk N" görünür. Aynı slotu başka öğrenciyle açınca o koltuk gri (dolu).
8. **(v3) Yönetim:** admin → *Yönetim → Odalar* → **Yeni oda** (ör. koltuk bazlı 20 koltuk) → **Düzenle** → **Kapat** (onayda yaklaşan rezervasyon sayısı) → **Geri aç**. *Kullanıcılar*'da bir öğrenciyi **Pasif yap** (giriş yapamaz) ve geri al, **Cezayı sıfırla**. *Rezervasyonlar*'da oda/durum filtresi, nedenli **İptal et**, **CSV indir**. "Admin odayı nereden ekliyor?" sorusunun cevabı artık Swagger'a geçmeden arayüzde.
9. **(v3) EN** düğmesiyle tüm arayüz İngilizceye, **☾ / ☀** ile gece/gündüz moduna geçer.
10. Swagger'da (`/docs`): `GET /suggestions` yanıtındaki skor bileşenleri, aynı slota `POST /reservations` → **409 `slot_full`** + `suggestions`; `GET /admin/holidays/2026` → harici API'den gelen tatiller, bir tatil gününe rezervasyon → **400 `holiday`**.
11. **Değerlendirme:** ogrenci1 → *Odalar*: kartlarda ★ ortalama puan ve ⚠ açık arıza rozetleri → bir oda → altta **Değerlendirmeler** (ortalama, 5→1 dağılım çubukları, son yorumlar) → **⚠ Arıza bildir** (tür + açıklama). *Rezervasyonlarım → Geçmiş*'te katılınan bir rezervasyonda **★ Puan ver** → yıldız + yorum → rozet ★ N'ye döner; aynı rezervasyona ikinci puan verilemez.
12. **Arıza yönetimi:** admin → *Yönetim → Arızalar* → az önce bildirilen arıza en üstte → **Çözüldü** (not yaz) → *Rapor → E-posta günlüğü*'nde öğrenciye giden "Arıza bildiriminiz çözüldü" e-postası; öğrencinin *Arıza bildirimlerim* listesinde durum ve not görünür.

## Git akışı

`main` korumalı dal; her özellik için `feature/<konu>` dalı açılıp pull request ile birleştirilir. `.github/workflows/ci.yml` her PR'da testleri ve Docker build'ini çalıştırır.

## Bilinen sınırlar

- Tek süreç varsayılır (`booking_lock` ve zamanlayıcı süreç içi). Birden fazla worker ile çalıştırılacaksa PostgreSQL + satır kilidi ve ayrı bir görev çalıştırıcı gerekir.
- Şema değişiklikleri için migration aracı (Alembic) yok; v3'ün iki yeni kolonu açılışta basit bir `ALTER TABLE` ile eklenir, daha karmaşık değişikliklerde `python -m scripts.seed --reset` ile sıfırlanır.
- Sunucu iş kuralı ve e-posta metinleri Türkçedir; İngilizce yalnızca web arayüzündedir (API hata kodları ve `params` dil bağımsızdır). Ceza/iptal nedenleri ve tatil adları veritabanında Türkçe saklanır; bilinen nedenler arayüzde çevrilir.
- Refresh token yok; access token süresi dolunca yeniden giriş yapılır.
- Check-in fiziksel varlığı kanıtlamaz: kod rezervasyon sahibine API yanıtında da döner, yani öğrenci odaya gelmeden `POST /checkin` çağırabilir. Gerçek kullanımda QR odadaki görevli tarafından okutulmalı (endpoint'i yalnızca admin'e açmak) ya da kod odaya ait olmalıdır.
- Pasife alınma tarihi tutulmaz; analitikte pasif bir odanın kapasitesi, rezervasyonu bulunan tarih aralığının tamamında sayılır.
- Bağımlılık sürümleri `requirements.txt` içinde sabittir; güncellerken testleri Python 3.12 ile (Docker imajı) yeniden koşun.
