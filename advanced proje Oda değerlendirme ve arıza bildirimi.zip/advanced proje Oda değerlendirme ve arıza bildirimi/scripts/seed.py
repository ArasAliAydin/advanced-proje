"""Demo verisi üretir: odalar, öğrenciler, önceki 3 haftanın rezervasyon geçmişi ve birkaç yaklaşan rezervasyon.

Kullanım:  python -m scripts.seed          (veritabanı boşsa doldurur)
           python -m scripts.seed --reset  (tüm tabloları silip yeniden oluşturur)
"""
import random
import sys
from datetime import datetime, time, timedelta

from sqlmodel import Session, SQLModel, select

from app.core import clock
from app.core.database import create_db_and_tables, engine
from app.core.security import hash_password
from app.main import ensure_admin
from app.models import (
    BookingMode,
    IssueReport,
    IssueStatus,
    Reservation,
    ReservationStatus,
    Role,
    Room,
    RoomRating,
    RoomType,
    User,
)
from app.services import reservation_service as rs

STUDENT_PASSWORD = "Student123!"  # yalnızca demo hesapları için

ROOMS = [
    dict(name="Grup Odası 1", location="Kütüphane 2. Kat", capacity=6, description="Akıllı tahta, 6 kişilik"),
    dict(name="Grup Odası 2", location="Kütüphane 2. Kat", capacity=4, slot_minutes=30),
    # Koltuk bazlı odalar: koltuk haritası için kapasite = koltuk sayısı, seats_per_row = bir sıradaki koltuk
    dict(name="Sessiz Çalışma Salonu", location="Kütüphane Zemin Kat", capacity=24, seats_per_row=8,
         room_type=RoomType.hall, booking_mode=BookingMode.shared, close_time=time(23, 0)),
    dict(name="Bilgisayar Lab A", location="Mühendislik B-104", capacity=12, seats_per_row=4, room_type=RoomType.lab,
         booking_mode=BookingMode.shared, open_time=time(9, 0), close_time=time(18, 0)),
]
STUDENTS = ["Ayşe Yılmaz", "Mehmet Demir", "Zeynep Kaya", "Can Öztürk", "Elif Şahin", "Burak Çelik"]


# Oda başına puan eğilimi (ağırlıklar 5..1 puan için) ve örnek yorumlar
RATING_WEIGHTS = {
    "Grup Odası 1": [55, 30, 10, 4, 1],
    "Grup Odası 2": [25, 35, 25, 10, 5],
    "Sessiz Çalışma Salonu": [60, 28, 8, 3, 1],
    "Bilgisayar Lab A": [15, 30, 30, 15, 10],
}
COMMENTS = {
    5: ["Çok sessiz, tam çalışmalık.", "Akıllı tahta harika, grup çalışması için ideal.", "Temiz ve aydınlık."],
    4: ["Güzel ama klima biraz soğuk.", "Rahat, sadece priz az.", "Genel olarak iyi."],
    3: ["İdare eder, biraz gürültülü.", "Sandalyeler rahatsız."],
    2: ["Bilgisayarların yarısı çok yavaş.", "Havalandırma yetersiz, çok sıcaktı."],
    1: ["Projeksiyon çalışmıyordu, sunum provası yapamadık."],
}
ISSUES = [
    ("Bilgisayar Lab A", "equipment", "4 numaralı bilgisayar açılmıyor, ekran siyah kalıyor.", None),
    ("Grup Odası 2", "power", "Pencere tarafındaki prizlerin hiçbiri çalışmıyor.", None),
    ("Sessiz Çalışma Salonu", "noise", "Havalandırma çok yüksek sesli çalışıyor.", "Fan bakımı yapıldı."),
]


def seed_feedback(session: Session, rooms: list[Room], students: list[User], now: datetime) -> tuple[int, int]:
    """Geçmiş tamamlanmış rezervasyonların bir kısmına puan ve birkaç arıza bildirimi ekler."""
    by_id = {r.id: r for r in rooms}
    by_name = {r.name: r for r in rooms}
    completed = session.exec(select(Reservation).where(Reservation.status == ReservationStatus.completed)).all()
    ratings = 0
    for reservation in completed:
        if random.random() > 0.2:
            continue
        room = by_id[reservation.room_id]
        score = random.choices([5, 4, 3, 2, 1], weights=RATING_WEIGHTS[room.name])[0]
        comment = random.choice(COMMENTS[score]) if random.random() < 0.35 else ""
        session.add(RoomRating(
            reservation_id=reservation.id, user_id=reservation.user_id, room_id=room.id, score=score,
            comment=comment, created_at=reservation.end_time + timedelta(minutes=random.randint(5, 600)),
        ))
        ratings += 1
    admin = session.exec(select(User).where(User.role == Role.admin)).first()
    for i, (room_name, category, description, resolution) in enumerate(ISSUES):
        created = now - timedelta(days=i + 1, hours=3)
        session.add(IssueReport(
            room_id=by_name[room_name].id, user_id=students[i].id, category=category, description=description,
            created_at=created,
            status=IssueStatus.resolved if resolution else IssueStatus.open,
            resolution_note=resolution,
            resolved_by=admin.id if resolution and admin else None,
            resolved_at=created + timedelta(hours=20) if resolution else None,
        ))
    session.commit()
    return ratings, len(ISSUES)


def seed() -> None:
    random.seed(42)
    now = clock.now()
    with Session(engine) as session:
        if session.exec(select(Room)).first():
            print("Veritabanında zaten veri var. Sıfırlamak için: python -m scripts.seed --reset")
            return
        rooms = [Room(**data) for data in ROOMS]
        hashed = hash_password(STUDENT_PASSWORD)
        students = [
            User(email=f"ogrenci{i}@example.com", full_name=name, hashed_password=hashed, role=Role.student)
            for i, name in enumerate(STUDENTS, start=1)
        ]
        session.add_all(rooms + students)
        session.commit()

        # Geçmiş: analitik endpoint'lerinin anlamlı veri döndürmesi için (öğlen saatleri daha yoğun).
        # Yalnızca önceki 3 tam haftaya yazılır: bu haftaya yazılsaydı öğrenciler haftalık limite
        # takılır ve demoda yeni rezervasyon yapamazdı.
        past = 0
        this_monday = now.date() - timedelta(days=now.weekday())
        for days_before in range(21, 0, -1):
            day = this_monday - timedelta(days=days_before)
            weekend = day.weekday() >= 5
            for room in rooms:
                seats = rs.seats_limit(room)
                for hour in range(room.open_time.hour, room.close_time.hour):
                    peak = 0.75 if 11 <= hour <= 16 else 0.35
                    for seat in range(1, seats + 1):
                        if random.random() > peak * (0.4 if weekend else 1):
                            continue
                        start = datetime.combine(day, time(hour))
                        status = random.choices(
                            [ReservationStatus.completed, ReservationStatus.no_show, ReservationStatus.cancelled],
                            weights=[82, 10, 8],
                        )[0]
                        session.add(
                            Reservation(
                                user_id=random.choice(students).id, room_id=room.id, start_time=start,
                                end_time=start + timedelta(hours=1), status=status,
                                seat_number=seat if room.booking_mode == BookingMode.shared else None,
                                checked_in_at=start if status == ReservationStatus.completed else None,
                                created_at=start - timedelta(days=1),
                            )
                        )
                        past += 1
        session.commit()

        ratings, issues = seed_feedback(session, rooms, students, now)

        # Gelecek: gerçek iş kurallarından geçirilerek oluşturulur
        upcoming = 0
        for day_offset in range(1, 4):
            for student in students:
                room = random.choice(rooms)
                start = datetime.combine((now + timedelta(days=day_offset)).date(), time(random.randint(10, 15)))
                try:
                    rs.create_reservation(session, student, room, start, start + timedelta(hours=1), now)
                    upcoming += 1
                except rs.BookingError:
                    pass
        session.commit()
    print(f"{len(ROOMS)} oda, {len(STUDENTS)} öğrenci, {past} geçmiş ve {upcoming} yaklaşan rezervasyon oluşturuldu.")
    print(f"{ratings} oda puanı ve {issues} arıza bildirimi eklendi.")
    print("Öğrenci hesapları: ogrenci1@example.com ... ogrenci6@example.com (şifre scripts/seed.py içinde)")


if __name__ == "__main__":
    if "--reset" in sys.argv:
        from app import models  # noqa: F401

        SQLModel.metadata.drop_all(engine)
    create_db_and_tables()
    ensure_admin()
    seed()
